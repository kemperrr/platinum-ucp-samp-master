<?php
session_start();
require 'system/application.php';
new Application();