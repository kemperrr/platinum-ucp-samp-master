# Platinum UCP
### Демо: [www.platinum-ucp.tk](http://platinum-ucp.tk)
### Описание: [brebvix Blog](http://brebvix.blogspot.com/2015/01/platinum-ucp-samp-v10.html)
### Скриншоты: [brebvix Blog](http://brebvix.blogspot.com/2015/01/platinum-ucp-samp.html)
### Документация: [GitHub Wiki](https://github.com/brebvix/platinum-ucp-samp/wiki)
